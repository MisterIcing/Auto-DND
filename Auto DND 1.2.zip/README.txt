1. Place folder anywhere (preferablly in a place without requiring admin)
2. Copy the address minus \Sheet.jar
3. Run the setup
4. Move Sheet.bat to the desktop so that it acts as a shortcut

Some Notes:
1. Command prompt is not always nice and will add odd characters and symbols. One is like aE^ and is an ' I think.
2. the default for the abbreviated version is no.
4. I hope the saving doesnt crash.
6. If there is an error, it might be my fault or you need java. Either way, it will tell you that you need Java.
5. Have Fun.
-2. The EULA and TOS are here somewhere...I think.
6. [Insert List Information Here].
9. This product is copyright protected by "This is My Stuff Corp."
17. I may or may not be collecting your data and selling it to China so that when they take over the world, I will not need to worry. 
4. Play Fire Emblem. Any and all of them.
7. 6 seasons and a movie.